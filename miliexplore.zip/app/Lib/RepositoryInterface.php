<?php

namespace App\Lib;


Interface RepositoryInterface
{
    public function getAll();

    public function getById($id);

    public function getByKyeId($key,$id);

    public function store(array $model);

    public function update(array $model,$id);

    public function delete($id);

    public function getModel();
}