<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

 // `ObjectName`, `ObjectDesc`, `CategoryType`, `SubCatId`,

class ObjectCat extends Model
{

		protected $table = 'object_cats';
        protected $fillable = [ 'ObjectCatName', 'ObjectDesc','SubCatId'];
}

