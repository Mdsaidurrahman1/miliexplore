<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SuperCategory extends Model
{
    protected $table = 'supercategories';
    protected $fillable = [ 'SuperCateName', 'SuperCateDesc', 'SuperCateType' ];
}
