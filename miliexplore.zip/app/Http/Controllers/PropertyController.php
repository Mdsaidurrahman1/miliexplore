<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Redirect,Session;
use App\Property;
use App\Lib\Repository;
use DB;


class PropertyController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    protected $mod;
    public function __construct(Property $link)
    {
        $this->mod = new Repository($link);
    }





    public function propertyinsert(Request $request)
    {
        $this->validate($request, [
            'PropertyName' => 'required'
        ]);

        $property = DB::select('select * from properties where PropertyName = ?',[$request->PropertyName]);
        if($property == null)
        {
            $property = $this->mod->store($request->only($this->mod->getModel()->fillable));
            return redirect()->route('objectdetail', ['id' => $request->objectid]);
        }else
        {
            $foundmsg = "Property Found";
             return redirect()->route('objectdetail', ['id' => $request->objectid])->with('foundmsg', $foundmsg);
        }


      

    }
        




    public function delete(Request $request)
    {
       $serviceDelete  =  $this->mod->getById($request->id);
       $serviceDelete->delete();
       return redirect('/categorysetup');
    }


    
}
