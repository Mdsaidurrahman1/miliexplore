<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Redirect,Session;
use App\SuperCategory;
use App\Lib\Repository;


class SuperCatController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    protected $mod;
    public function __construct(SuperCategory $link)
    {
        $this->mod = new Repository($link);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $supercatpack  =  $this->mod->getAll();
        return view('admin.supercatsetup')->with('supercatpack',$supercatpack);
    }


    public function create(Request $request)
    {
        $this->validate($request, [
            'SuperCateName' => 'required'
        ]);

       $sitepost = $this->mod->store($request->only($this->mod->getModel()->fillable));
       return redirect('/Supercatsetup');
    }



    public function delete(Request $request)
    {
       $serviceDelete  =  $this->mod->getById($request->id);
       $serviceDelete->delete();
       return redirect('/Supercatsetup');
    }


    
}
