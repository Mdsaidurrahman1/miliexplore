<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Linkrefference extends Model
{
    protected $fillable = [ 'SiteName', 'SiteDesc', 'SiteCategory', 'SiteType','ObjCatId','SupCatId','CatId','SubCatId', 'SiteUrl', 'SiteWorkingUrl'];
}
