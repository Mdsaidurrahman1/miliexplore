<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ObjectEn extends Model
{
	protected $table = 'object_ens';
    protected $fillable = [ 'ObjectName','ObjectType','ObjectDetail','SupCatId','CatId','SubCatId', 'ObjectCateId'];
}
