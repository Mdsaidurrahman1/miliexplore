<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ObjectReference extends Model
{
    	protected $table = 'object_references';
        protected $fillable = [ 'ObjectId', 'Property','Value'];
}
