<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActionLib extends Model
{
        protected $fillable = [ 'ActionName','ObjectId','InputParameter', 'OutputReturns'];
}
