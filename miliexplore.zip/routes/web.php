<?php
// Auth::routes();

//**********************************************************************
// ------------------- Home Site Basic Route ---------------------------
//====================----------------------============================

Route::get('/','HomeController@index')->name('root');
Route::get('/about','HomeserviceController@companydetail')->name('about');
Route::post('/usermessage','MessageController@messagepost')->name('usermessage');


//**********************************************************************
// ------------------ User releted Route -------------------------------
//====================----------------------============================

//--- user management --------------------------------
Route::get('/login','UserController@login')->name('userlogin');
Route::get('/register','UserController@register')->name('userregister');
Route::post('/loginpost', 'UserController@loginpost')->name('loginpost');
Route::post('/registerpost', 'UserController@registerpost')->name('registerpost');


//--- order management --------------------------------





Route::group(['middleware'=>'preventback'], function()
{
	Route::get('/signout', 'UserController@signout')->name('signout');
});

//**********************************************************************
// ------------------------ Secure Route -------------------------------
//====================----------------------============================

Route::group(['middleware'=>'checkauthencation'], function()
{

	Route::get('/admin', 'AdminController@admin');



	Route::get('/module','ModuleController@index')->name('module');
	Route::post('/addmodule','ModuleController@create')->name('addmodule');

	// Admin operation [Link Library] -----------------------------------------------------------
	Route::get('/linklib', 'LinkController@index')->name('linklib');
	Route::get('/webdirectory', 'LinkController@webdirectory')->name('webdirectory');
	Route::post('/linkpost', 'LinkController@create')->name('linkpost');
	Route::get('/linkdelete/{id}','linkController@delete')->name('deletelink');
	Route::get('/linkdetail/{id}','linkController@linkDetail')->name('linkdetail');
























	// Admin operation [Object Library] -----------------------------------------------------------
	Route::post('/propertyin', 'PropertyController@propertyinsert')->name('propertyin');

	Route::get('/object', 'ObjectController@index')->name('object');
	Route::post('/objectentitypost', 'ObjectController@create')->name('objectentitypost');
	Route::get('/objectdetail/{id}', 'ObjectController@detail')->name('objectdetail');
	Route::get('/objdelete/{id}','ObjectController@delete')->name('objdelete');

	


	Route::post('/objpropertyentry', 'ObjectRefController@propertyEntry')->name('objpropertyentry');
	Route::post('/objactionentry', 'ObjectActionController@actionEntry')->name('objactionentry');



	// Ajax Request handler route -----------------------------------------------------------
	Route::get('/ajaxreq', 'SearchController@ajaxresponse')->name('ajaxreq'); // for web links
	Route::get('/getbySupCat', 'SearchController@getObjBySupCat')->name('getbySupCat'); // for web links
	Route::get('/getbyCat', 'SearchController@getObjByCat')->name('getbyCat'); // for web links
	Route::get('/getbySubCat', 'SearchController@getObjBySubCat')->name('getbySubCat'); // for web links

	//Route::get('/category','LinkController@ajaxcall')->name('getcatajaxcall');
	Route::get('/getcategory','CategoryController@ajaxcall')->name('getcatajaxcall');
	Route::get('/getsubcategory','SubCategoryController@ajaxcall')->name('subcatajaxcall');
	Route::get('/getobjcat','ObjectCatController@ajaxcall')->name('subcatajaxcall');

	Route::get('/searchBySupCate','SearchController@SuperCatRequest')->name('searchBySupCate');
	Route::get('/searchByCate','SearchController@CatRequest')->name('searchByCate');
	Route::get('/searchBySubCate','SearchController@SubCatRequest')->name('searchBySubCate');
	Route::get('/searchByObjCate','SearchController@ObjCatRequest')->name('searchByObjCate');



	//Route::get('/objcatreq', 'AjaxController@objectcateReq')->name('objcatreq');
	


// Reporting handler route -----------------------------------------------------------
	Route::get('/reportshow', 'ReportController@showreport')->name('reportshow');
	Route::get('/report', 'ReportController@report')->name('report');









	// Admin operation [Settings] -----------------------------------------------------------
	Route::get('/Settings', 'SettingsController@index')->name('settingsmodule');


	Route::get('/Supercatsetup', 'SuperCatController@index')->name('Supercatsetup');
	Route::post('/supercatpost', 'SuperCatController@create')->name('supercatpost');
	Route::get('/supercatdelete/{id}','SuperCatController@delete')->name('supercatdelete');

	Route::get('/categorysetup', 'CategoryController@index')->name('Categorysetup');
	Route::post('/categorypost', 'CategoryController@create')->name('categorypost');
	Route::get('/categorydelete/{id}','CategoryController@delete')->name('categorydelete');

	Route::get('/subcategorysetup', 'SubCategoryController@index')->name('Subategorysetup');
	Route::post('/subcategorypost', 'SubCategoryController@create')->name('subcategorypost');
	Route::get('/subcatdelete/{id}','SubCategoryController@delete')->name('subcatdelete');

	Route::get('/Objectcatsetup', 'ObjectCatController@index')->name('Objectcatsetup');
	Route::post('/objectpost', 'ObjectCatController@create')->name('objectpost');
	Route::get('/objectdelete/{id}','ObjectCatController@delete')->name('objectdelete');



});

















