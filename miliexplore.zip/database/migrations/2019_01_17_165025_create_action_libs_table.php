<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateActionLibsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('action_libs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('ActionName',20);
            $table->string('InputParameter',200);
            $table->string('OutputReturns',200);
            $table->integer('ObjectId')->unsigned()->index();
            $table->foreign('ObjectId')->references('id')->on('object_ens')->onDelete('cascade')->onUpdate('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('action_libs');
    }
}
