-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2019 at 09:56 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `miliexplorer`
--

-- --------------------------------------------------------

--
-- Table structure for table `action_libs`
--

CREATE TABLE `action_libs` (
  `id` int(10) UNSIGNED NOT NULL,
  `ActionName` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `InputParameter` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OutputReturns` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ObjectId` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `CategoryName` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CategoryDesc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CategoryType` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SuperCateId` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `CategoryName`, `CategoryDesc`, `CategoryType`, `SuperCateId`, `created_at`, `updated_at`) VALUES
(41, 'Business', 'Business website links', NULL, 22, '2019-01-19 01:45:15', '2019-01-19 01:45:15'),
(42, 'Jobs portal', 'Website that provide jobs information', NULL, 22, '2019-01-19 01:46:29', '2019-01-19 01:46:29'),
(43, 'Banks', 'Banks website links', NULL, 22, '2019-01-19 01:47:05', '2019-01-19 01:47:05'),
(45, 'Education', 'Education provider websites', NULL, 22, '2019-01-19 01:48:23', '2019-01-19 01:48:23'),
(46, 'Government Institution', 'Government  operated websites', NULL, 22, '2019-01-19 01:51:32', '2019-01-19 01:51:32'),
(47, 'Social Media', 'Social media websites', NULL, 22, '2019-01-19 01:52:04', '2019-01-19 01:52:04'),
(48, 'Email & Communication', 'Email and communication websites', NULL, 22, '2019-01-19 01:52:43', '2019-01-19 01:52:43'),
(49, 'Educational Institutional', 'Educational providers website', 'Logical', 22, '2019-01-19 02:20:17', '2019-01-19 02:20:17'),
(50, 'NGO', 'Non governmental org', 'Logical', 22, '2019-01-19 02:20:56', '2019-01-19 02:20:56');

-- --------------------------------------------------------

--
-- Table structure for table `linkrefferences`
--

CREATE TABLE `linkrefferences` (
  `id` int(10) UNSIGNED NOT NULL,
  `SiteName` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SiteDesc` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SiteCategory` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SiteType` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SupCatId` int(11) DEFAULT NULL,
  `CatId` int(11) DEFAULT NULL,
  `SubCatId` int(11) DEFAULT NULL,
  `ObjCatId` int(11) DEFAULT NULL,
  `SiteUrl` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SiteWorkingUrl` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `linkrefferences`
--

INSERT INTO `linkrefferences` (`id`, `SiteName`, `SiteDesc`, `SiteCategory`, `SiteType`, `SupCatId`, `CatId`, `SubCatId`, `ObjCatId`, `SiteUrl`, `SiteWorkingUrl`, `created_at`, `updated_at`) VALUES
(35, 'UCEP', NULL, 'School', 'Education/Academic/School', 19, 34, 27, NULL, 'http://www.ucepbd.org/', NULL, '2019-01-18 00:26:44', '2019-01-18 00:26:44'),
(36, 'UNicef', 'dfgd', 'Child Rights', 'Institution/International/Child Rights', 20, 39, 23, NULL, 'https://www.unicef.org/', NULL, '2019-01-19 00:37:25', '2019-01-19 00:37:25'),
(37, 'Save the Children International', NULL, 'Child Rights', 'Institution/International/Child Rights', 20, 39, 23, 28, 'https://www.savethechildren.org/', NULL, '2019-01-19 00:39:35', '2019-01-19 00:39:35'),
(38, 'BDJobs', NULL, 'National', 'Website Refference/Jobs portal/National', 22, 42, 30, NULL, 'http://www.bdjobs.com/', NULL, '2019-01-19 02:24:30', '2019-01-19 02:24:30'),
(39, 'CV Link', NULL, 'National', 'Website Refference/Jobs portal/National', 22, 42, 30, NULL, 'https://cvlinked.com/', NULL, '2019-01-19 02:25:19', '2019-01-19 02:25:19'),
(40, 'Dutch Bangla Bank Ltd', NULL, 'Private Banks', 'Website Refference/Banks/Private Banks', 22, 43, 32, NULL, 'https://www.dutchbanglabank.com/', NULL, '2019-01-19 02:33:33', '2019-01-19 02:33:33');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_11_06_181103_service', 1),
(2, '2018_11_09_164856_create_works_table', 2),
(3, '2018_11_10_050147_create_messages_table', 3),
(4, '2018_11_24_062936_create_linkrefferences_table', 4),
(5, '2018_11_24_072507_create_super_catetories_table', 5),
(6, '2018_11_24_073148_create_catetories_table', 6),
(7, '2018_11_24_073847_create_catetories_table', 7),
(8, '2018_11_24_074138_create_sub_catetories_table', 8),
(9, '2018_11_28_033253_create_object_cats_table', 9),
(10, '2018_12_06_171939_create_objects_table', 10),
(11, '2018_12_06_172451_create_properties_table', 11),
(12, '2018_12_06_173302_create_actions_table', 12),
(13, '2019_01_03_175915_create_properties_table', 13),
(14, '2019_01_11_165101_create_modules_table', 14),
(15, '2019_01_17_061700_create_object_references_table', 15),
(16, '2019_01_17_165025_create_action_libs_table', 16);

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `id` int(10) UNSIGNED NOT NULL,
  `ModuleName` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ModuleDesc` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `object_cats`
--

CREATE TABLE `object_cats` (
  `id` int(10) UNSIGNED NOT NULL,
  `ObjectCatName` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ObjectDesc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CategoryType` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SubCatId` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `object_cats`
--

INSERT INTO `object_cats` (`id`, `ObjectCatName`, `ObjectDesc`, `CategoryType`, `SubCatId`, `created_at`, `updated_at`) VALUES
(21, 'Student', NULL, NULL, 27, '2019-01-18 00:12:44', '2019-01-18 00:12:44'),
(22, 'Teacher', NULL, NULL, 27, '2019-01-18 00:13:04', '2019-01-18 00:13:04'),
(23, 'Module', NULL, NULL, 28, '2019-01-18 00:13:41', '2019-01-18 00:13:41'),
(24, 'Trainer', NULL, NULL, 28, '2019-01-18 00:14:15', '2019-01-18 00:14:15'),
(27, 'UNICEF', 'UNICEF int. organization', NULL, 23, '2019-01-19 00:14:18', '2019-01-19 00:14:18'),
(28, 'Save the Children', 'Child rights int. organization', NULL, 23, '2019-01-19 00:15:01', '2019-01-19 00:15:01');

-- --------------------------------------------------------

--
-- Table structure for table `object_ens`
--

CREATE TABLE `object_ens` (
  `id` int(10) UNSIGNED NOT NULL,
  `ObjectName` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ObjectDetail` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ObjectType` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SupCatId` int(11) DEFAULT NULL,
  `CatId` int(11) DEFAULT NULL,
  `SubCatId` int(11) DEFAULT NULL,
  `ObjectCateId` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `object_ens`
--

INSERT INTO `object_ens` (`id`, `ObjectName`, `ObjectDetail`, `ObjectType`, `SupCatId`, `CatId`, `SubCatId`, `ObjectCateId`, `created_at`, `updated_at`) VALUES
(20, 'Class', NULL, 'Education/Academic/School/Student', 19, 34, 27, 21, '2019-01-18 00:28:50', '2019-01-18 00:28:50');

-- --------------------------------------------------------

--
-- Table structure for table `object_references`
--

CREATE TABLE `object_references` (
  `id` int(10) UNSIGNED NOT NULL,
  `Property` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Value` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ObjectId` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `id` int(10) UNSIGNED NOT NULL,
  `PropertyName` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `SubCatName` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SubCatDesc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SubCatType` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CategoryId` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `SubCatName`, `SubCatDesc`, `SubCatType`, `CategoryId`, `created_at`, `updated_at`) VALUES
(22, 'Education Provider', 'In. organization working in education', 'Physical', 39, '2019-01-17 23:29:06', '2019-01-17 23:29:06'),
(23, 'Child Rights', 'In. organization working in child rights', 'Physical', 39, '2019-01-17 23:30:40', '2019-01-17 23:30:40'),
(24, 'Refugee rights', 'In. organization working in refugee rights', 'Physical', 39, '2019-01-17 23:31:53', '2019-01-17 23:31:53'),
(25, 'Disaster Management', 'In. organization working in In. organization working on disaster management', 'Physical', 39, '2019-01-17 23:34:01', '2019-01-17 23:34:01'),
(26, 'School', 'fghh', 'fgh', 37, '2019-01-18 00:02:09', '2019-01-18 00:02:09'),
(27, 'School', 'jhgtyr', NULL, 34, '2019-01-18 00:04:11', '2019-01-18 00:04:11'),
(28, 'Training', 'trtrt', NULL, 35, '2019-01-18 00:04:27', '2019-01-18 00:04:27'),
(30, 'National', 'Country wise', NULL, 42, '2019-01-19 02:23:17', '2019-01-19 02:23:17'),
(31, 'International', 'International job site', NULL, 42, '2019-01-19 02:23:42', '2019-01-19 02:23:42'),
(32, 'Private Banks', 'Private operated banks', NULL, 43, '2019-01-19 02:31:21', '2019-01-19 02:31:21'),
(33, 'Public Banks', 'Govt operated banks', NULL, 43, '2019-01-19 02:31:47', '2019-01-19 02:31:47');

-- --------------------------------------------------------

--
-- Table structure for table `supercategories`
--

CREATE TABLE `supercategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `SuperCateName` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SuperCateDesc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SuperCateType` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `supercategories`
--

INSERT INTO `supercategories` (`id`, `SuperCateName`, `SuperCateDesc`, `SuperCateType`, `created_at`, `updated_at`) VALUES
(19, 'Education', 'Prime demands of human beings', 'Logical', '2019-01-17 23:15:57', '2019-01-17 23:15:57'),
(20, 'Institution', 'Place or station for human beings', 'Physical', '2019-01-17 23:17:08', '2019-01-17 23:17:08'),
(21, 'Business', 'Profession', 'Logical', '2019-01-19 01:42:39', '2019-01-19 01:42:39'),
(22, 'Website Refference', 'Website address', 'Logical', '2019-01-19 01:44:08', '2019-01-19 01:44:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `date_of_birth`, `contact_no`, `role`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'Saidur', 'Rahman', 'saidur', NULL, NULL, NULL, 'rahman0@gmail.com', NULL, 'asdf', 'ZkuSqexJebCSEsFCIgTBpBWhN23I5ILFN8AtIUvbhGw6FlRgjaXrP7uZxL0L', '2018-10-28 03:37:47', '2018-10-28 03:37:47'),
(4, 'as', 'df', 'asdf', NULL, NULL, NULL, 'as@df.con', NULL, '$2y$10$AzowueYP2qhR54yoJY/bQ.5FBVyh/FgYKpYTRh/mXOQa13cb2sCnS', '4bxRL6yPM8hBqsleXyLMtO6j2i04TuFUhiSfIB69uxp4iosn5pKYzqxM4Cv7', '2018-10-29 12:14:34', '2018-10-29 12:14:34'),
(5, NULL, NULL, 'mili', NULL, NULL, NULL, 'mili@mili.com', NULL, 'asdf', NULL, '2019-01-02 11:20:51', '2019-01-02 11:20:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `action_libs`
--
ALTER TABLE `action_libs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `action_libs_objectid_index` (`ObjectId`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catetories_supercateid_index` (`SuperCateId`);

--
-- Indexes for table `linkrefferences`
--
ALTER TABLE `linkrefferences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `object_cats`
--
ALTER TABLE `object_cats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `object_cats_subcatid_index` (`SubCatId`);

--
-- Indexes for table `object_ens`
--
ALTER TABLE `object_ens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `objects_objectcateid_index` (`ObjectCateId`);

--
-- Indexes for table `object_references`
--
ALTER TABLE `object_references`
  ADD PRIMARY KEY (`id`),
  ADD KEY `object_references_objectid_index` (`ObjectId`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub_catetories_categoryid_index` (`CategoryId`);

--
-- Indexes for table `supercategories`
--
ALTER TABLE `supercategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `action_libs`
--
ALTER TABLE `action_libs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `linkrefferences`
--
ALTER TABLE `linkrefferences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `object_cats`
--
ALTER TABLE `object_cats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `object_ens`
--
ALTER TABLE `object_ens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `object_references`
--
ALTER TABLE `object_references`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `supercategories`
--
ALTER TABLE `supercategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `action_libs`
--
ALTER TABLE `action_libs`
  ADD CONSTRAINT `action_libs_objectid_foreign` FOREIGN KEY (`ObjectId`) REFERENCES `object_ens` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `catetories_supercateid_foreign` FOREIGN KEY (`SuperCateId`) REFERENCES `supercategories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `object_cats`
--
ALTER TABLE `object_cats`
  ADD CONSTRAINT `object_cats_subcatid_foreign` FOREIGN KEY (`SubCatId`) REFERENCES `subcategories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `object_references`
--
ALTER TABLE `object_references`
  ADD CONSTRAINT `object_references_objectid_foreign` FOREIGN KEY (`ObjectId`) REFERENCES `object_ens` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
