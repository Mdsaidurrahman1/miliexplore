@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="login" class="login">
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-4 col-lg-offset-2 loginform" >


              @if(Session::has('Successmessage'))
                  <div class="alert alert-info">
                      User Created successfully! Please login
                </div>
             @endif
              
            @if (Session::has('message'))
               <div class="alert alert-danger">{{ Session::get('message') }}</div>
            @endif

              <br>
              <h2> Login here</h2>  
              <form action="{{ route('loginpost') }}" method="POST" >
                @csrf
                <input type="hidden" name="" value="">

                <label class=""> User name</label><br>
                <input type="text" name="username" class="form-control" value="saidur" placeholder="Enter name">

                <br><label class=""> User Password</label><br>
                <input type="password" name="userpassword" class="form-control" value="asdf" placeholder="Enter password">

               <br><input type="submit" class="btn btn-info"value="Login">
                <br>

              </form>


        </div>
        <div class="col-lg-4 col-lg-offset-2">
            
        </div>
        <div class="col-lg-4 col-lg-offset-2">

        </div>
      </div>

    </div>


  </section>
  <!-- /Section: services -->


@endsection


 