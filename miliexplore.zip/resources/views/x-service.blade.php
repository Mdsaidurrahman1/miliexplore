@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="service" style="background-image:url({{ URL::asset('resources/assets/img/bg.png') }})" class="service" >
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-8 col-lg-offset-2">
          <div class="wow flipInY" data-wow-offset="0" data-wow-delay="0.4s">
            <div class="section-heading text-center">
              <h2 class="h-bold">Our Service for you</h2>

            </div>
          </div>
        </div>
      </div>

    </div>

    <div class="text-center">
      <div class="container">

        <div class="row">

          <div class="col-md-3">
            <div class="wow fadeInLeft" data-wow-delay="0.2s">
              <div class="service-box">
                <div class="service-icon">
                  <img src="{{ URL::asset('resources/assets/img/service1.jpg') }}" class="img-responsive" alt="img">
                </div>
                <div class="service-desc">
                  <h5>Making Furniture</h5>
                  <a href="#" class="btn btn-skin">See more</a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-3">
            <div class="wow fadeInUp" data-wow-delay="0.2s">
              <div class="service-box">
                <div class="service-icon">
                  <img src="{{ URL::asset('resources/assets/img/service2.jpg') }}" class="img-responsive" alt="img">
                </div>
                <div class="service-desc">
                  <h5>Repairing furnitures</h5>
                  <a href="#" class="btn btn-skin">See more</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="wow fadeInUp" data-wow-delay="0.2s">
              <div class="service-box">
                <div class="service-icon">
                  <img src="{{ URL::asset('resources/assets/img/service3.jpg') }}" class="img-responsive" alt="img">
                </div>
                <div class="service-desc">
                  <h5>Color and Burnish</h5>
                  <a href="#" class="btn btn-skin">See more</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="wow fadeInRight" data-wow-delay="0.2s">
              <div class="service-box">
                <div class="service-icon">
                  <img src="{{ URL::asset('resources/assets/img/service4.jpg') }}" class="img-responsive" alt="img">
                </div>
                <div class="service-desc">
                  <h5>Cleaning furnitures</h5>
                  <a href="#" class="btn btn-skin">See more</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- /Section: services -->


@endsection


 