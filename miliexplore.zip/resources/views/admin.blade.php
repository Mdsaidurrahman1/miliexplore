@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">

              <a href="{{route('linklib')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Web Refference</a> 
              <a href="{{route('object')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Object Library</a> 
               <a href="{{route('settingsmodule')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Setup Module</a>  
               <a href="{{route('settingsmodule')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Setup </a>  
               <a href="{{route('module')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Working Module </a>  
              <a href="{{route('report')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Show report</a> 
             
          </div>

          <div class="col-md-10">
            <p class="subtitle" > All Module</p> <hr>

                 @foreach ($modulepack as $mod)
                  <a href="">
                      <div class="col-md-3 modhead">
                      <h4>{{ $mod->ModuleName }}</h4>
                      <h5>{{ $mod->ModuleDesc }}</h5>
                    </div>
                  </a>

                  @endforeach

          </div>

    </div>

  </section>
  <!-- /Section: services -->


@endsection


 