@extends('template')

@section('content')
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red"> Message Management</span></p>
          </div>
        </div>
      </div>
<i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
              <a href="{{url('/admin')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Admin Operation</a>
          </div>

          <div class="col-md-10">

            <p style="padding: 5px; font-size: 22px;"> Site message management</p><hr>

           <div class="contentsection">

              <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Sender</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Type</th>
                    <th scope="col" style="width: 30%; text-align: left;">Message</th>
                    <th scope="col">Time</th>
                    <th scope="col" style="text-align: right;">Manage message</th>
                  </tr>
                </thead>
                <tbody>

                  @php $i = 1 @endphp
                  @foreach ($message as $msg)
                  <tr>
                    <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                    <td> {{ $msg->Sender_name }}</td>
                    <td> {{ $msg->Message_subject }}</td>
                    <td>{{ $msg->Sender_email }} <br>{{ $msg->Sender_contact }}</td>
                    <td>{{ $msg->Type }}</td>
                    <td><span style="color: #353090">{{ $msg->Message }}</span></td>
                    <td>{{ $msg->created_at }}</td>
                    <td style="text-align: right;">
                      <a href="{{url('/messagedelete/'.$msg->id)}}" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  @endforeach
                  
                  
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>



@endsection


 