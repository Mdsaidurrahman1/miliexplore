@extends('template')

@section('content')
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red"> Setup Info Management</span></p>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
              <a href="{{url('/admin')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Admin Operation</a> 
              <a href="{{route('Supercatsetup')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Super Categoty</a> 
              <a href="{{route('Categorysetup')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Categoty</a>  
              <a href="{{route('Subategorysetup')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Sub Categoty</a>  
              <a href="{{route('Objectcatsetup')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Object Categoty</a> 

             
          </div>


          <div class="col-md-10">
              <p class="subtitle" > All Registered Categories</p> <hr>
              


              <div class="col-md-3">
                <p>Super Category </p>
                <table class="table table-sm table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Name</th>
                      <th scope="col" style="width: 30%; text-align: right;">Service</th>
                    </tr>
                  </thead>
                  <tbody>
                    @php $i = 1 @endphp
                    @foreach ($supcate as $link)
                    <tr>
                      <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                      <td> {{ $link->SuperCateName }}</td>
                      <td style="width: 30%; text-align: right;">
                        <a href="{{url('/supercatdelete/'.$link->id)}}" class="btn btn-sm btn-danger"> Delete </a>
                      </td>
                    </tr>
                    @endforeach
                  </tbody>
              </table>
              </div>

                <div class="col-md-3">
                  <p>Category </p>
                <table class="table table-sm table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Name</th>
                      <th scope="col" style="width: 30%; text-align: right;">Service</th>
                    </tr>
                  </thead>
                  <tbody>
                    @php $i = 1 @endphp
                    @foreach ($cate as $link)
                    <tr>
                      <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                      <td> {{ $link->CategoryName }}</td>
                      <td style="width: 30%; text-align: right;">
                        <a href="{{url('/categorydelete/'.$link->id)}}" class="btn btn-sm btn-danger"> Delete </a>
                      </td>
                    </tr>
                    @endforeach
                  </tbody>
              </table>
              </div>

              <div class="col-md-3">
                <p>Sub Category </p>
                <table class="table table-sm table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Name</th>
                      <th scope="col" style="width: 30%; text-align: right;">Manage</th>
                    </tr>
                  </thead>
                  <tbody>
                    @php $i = 1 @endphp
                    @foreach ($subcate as $link)
                    <tr>
                      <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                      <td> {{ $link->SubCatName }}</td>
                      <td style="width: 30%; text-align: right;">
                        <a href="{{url('/subcatdelete/'.$link->id)}}" class="btn btn-sm btn-danger"> Delete </a>
                      </td>
                    </tr>
                    @endforeach
                  </tbody>
              </table>
              </div>

                <div class="col-md-3">
                  <p>Object Category </p>
                <table class="table table-sm table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Name</th>
                      <th scope="col" style="width: 30%; text-align: right;">Service</th>
                    </tr>
                  </thead>
                  <tbody>
                    @php $i = 1 @endphp
                    @foreach ($objcate as $link)
                    <tr>
                      <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                      <td> {{ $link->ObjectCatName }}</td>
                      <td style="width: 30%; text-align: right;">
                        <a href="{{url('/objectdelete/'.$link->id)}}" class="btn btn-sm btn-danger"> Delete </a>
                      </td>
                    </tr>
                    @endforeach
                  </tbody>
              </table>
              </div>




          </div>

    </div>

  </section>



@endsection


   
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert New Service in Business</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
    </div>
  </div>
</div>



