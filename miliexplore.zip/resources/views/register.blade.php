@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="login" class="login">
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-4 col-lg-offset-2 loginform" >

          @if ($errors->any())
              <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                          <li>{{ $error }}</li>
                      @endforeach
                  </ul>
              </div>
          @endif




            <h2> Register here</h2>  
                  @if (Session::has('message'))
                     <div class="alert alert-warning">{{ Session::get('message') }}</div>
                  @endif
              <form action="{{ route('registerpost') }}" method="POST" >
                @csrf
                <input type="hidden" name="" value="">

                <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="username" aria-describedby="emailHelp" placeholder="Enter user name">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Email</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Password</label>
                  <input type="password" class="form-control" id="exampleInputEmail1" name="password" aria-describedby="emailHelp" placeholder="Enter email">
                </div>

               <br><input type="submit" class="btn btn-info"value="Register">
                <br>

              </form>


        </div>
        <div class="col-lg-4 col-lg-offset-2">
            
        </div>
        <div class="col-lg-4 col-lg-offset-2">

        </div>
      </div>

    </div>


  </section>
  <!-- /Section: services -->


@endsection


 