@extends('template')

@section('content')
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red">Link Library Management</span></p>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
              <a href="{{url('/admin')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Admin Operation</a>
              <a href="{{route('linklib')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Web Refference</a>               
          </div>



          <div class="col-md-10">


            <div class="row searchbar">
              <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">Super Category</label>
                  <select class="form-control" id="supercategory" name="supercategory">
                    <option class="Education">Select Category</option>
                      @foreach ($catpack as $cat)
                          <option value="{{ $cat->id }}">{{$cat->SuperCateName }}</option>
                      @endforeach
                  </select>
                </div>
                
              </div>

              <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">Category</label>
                  <select class="form-control" id="category" name="category">
                    <option class="Education">Select Category</option>
                  </select>
                </div>

                
              </div>

              <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">Sub Category</label>
                  <select class="form-control" id="subcategory" name="subcategory">
                    <option class="Education">Select Category</option>
                  </select>
                </div>
              </div>

              <div class="col-md-2" id="addtbn" >
                <div class="form-group">
                  <label for="exampleInputEmail1">Add new web link</label>
                    <button type="button"  class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                      Add Link
                    </button>
                </div>
              </div>


            </div>


           <div class="contentsection">
    
                  @if (Session::has('message'))
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> {{Session::get('message') }}    
                  </div>
                  @endif

             <p class="subtitle" > All site info</p>

              <table  id="webdirtable" class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Site Name</th>
                    <th scope="col">Site Link</th>
                    <th scope="col">Description</th>
                    <th scope="col">Type </th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage Service</th>
                  </tr>
                </thead>
                <tbody>
                  @php $i = 1 @endphp
                  @foreach ($linkpack as $link)
                  <tr>
                    <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                    <td> {{ $link->SiteName }}</td>
                    <td> {{ $link->SiteUrl }}</td>
                    <td>{{ $link->SiteDesc }}</td>
                    <td>{{ $link->SiteType }}</td>
                    <td style="width: 30%; text-align: right;">
                      <a href="" class="btn btn-sm btn-primary"> Add </a>
                      <a href="{{($link->SiteUrl)}}" target="_Blank" class="btn btn-sm btn-info"> Browse </a>
                    </td>
                  </tr>

                  @endforeach
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>


<script type="text/javascript">


  $( "#addtbn" ).hide() ;

$(document).ready(function(){


    


  $( "#supercategory" ).change(function() {
  var supcatid = $("#supercategory").val();

         $.ajax({
          url:"{{url('/getbySupCat') }}",
          method: 'GET',
          data: {'key':supcatid},
            
          success: function(data)
          {
            $('#webdirtable').html('');
            
            $('#webdirtable').append('<thead><tr><th scope="col">#</th><th scope="col">Site Name</th><th scope="col">Site Link</th><th scope="col">Description</th><th scope="col">Type </th><th scope="col" style="width: 30%; text-align: right;">Manage Service</th></tr></thead><tbody>');

             $.each(data, function( key, value ) 
             {
              $('#webdirtable').append('<tr><td scope="row">'+ ++key +'</td>                    <td> '+ value.SiteName +'</td>        <td> '+ value.SiteUrl +'</td>        <td>'+ value.SiteDesc +'</td>        <td>'+ value.SiteType +'</td>        <td style="width: 30%; text-align: right;"><a href="'+ value.SiteUrl +'" target="_Blank" class="btn btn-sm btn-info"> Browse </a>                 </td>    </tr>');
              });
             $('#webdirtable').append('</tbody>');
          },
        });

         $.ajax({
          url:"{{url('/getcategory') }}",
          method: 'GET',
          data: {'key':supcatid},
          success: function(result)
          {
             $('#category').html('');
             $('#category').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) 
             {
                $('#category').append('<option value="'+value.id+'">'+ value.CategoryName +'</option>');
             });
          },
          });

  });



  $( "#category" ).change(function() {
  var supcatid = $("#supercategory").val();
  var catid = $("#category").val();
         $.ajax({
          url:"{{url('/getbyCat') }}",
          method: 'GET',
          data: {'supCkey':supcatid, 'catkey':catid},
            
          success: function(data)
          {
            $('#webdirtable').html('');
            
            $('#webdirtable').append('<thead><tr><th scope="col">#</th><th scope="col">Site Name</th><th scope="col">Site Link</th><th scope="col">Description</th><th scope="col">Type </th><th scope="col" style="width: 30%; text-align: right;">Manage Service</th></tr></thead><tbody>');

             $.each(data, function( key, value ) 
             {
              $('#webdirtable').append('<tr><td scope="row">'+ ++key +'</td>                    <td> '+ value.SiteName +'</td>        <td> '+ value.SiteUrl +'</td>        <td>'+ value.SiteDesc +'</td>        <td>'+ value.SiteType +'</td>        <td style="width: 30%; text-align: right;"><a href="'+ value.SiteUrl +'" target="_Blank" class="btn btn-sm btn-info"> Browse </a></td>    </tr>');
              });
             $('#webdirtable').append('</tbody>');
          },
        });

         $.ajax({
          url:"{{url('/getsubcategory') }}",
          method: 'GET',
          data: {'key':catid},
          success: function(result)
          {
             $('#subcategory').html('');
             $('#subcategory').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) 
             {
                $('#subcategory').append('<option value="'+value.id+'">'+ value.SubCatName +'</option>');
             });
          },
          });

  });




  $( "#subcategory" ).change(function() {
    var supcatid = $("#supercategory").val();
    var catid = $("#category").val();
    var subcatid = $("#subcategory").val();
      $( "#addtbn" ).show() ;
         $.ajax({
          url:"{{url('/getbySubCat') }}",
          method: 'GET',
          data: {'supCkey':supcatid, 'catkey':catid, 'subckey':subcatid},
            
          success: function(data)
          {
            $('#webdirtable').html('');
            
            $('#webdirtable').append('<thead><tr><th scope="col">#</th><th scope="col">Site Name</th><th scope="col">Site Link</th><th scope="col">Description</th><th scope="col">Type </th><th scope="col" style="width: 30%; text-align: right;">Manage Service</th></tr></thead><tbody>');

             $.each(data, function( key, value ) 
             {
              $('#webdirtable').append('<tr><td scope="row">'+ ++key +'</td>                    <td> '+ value.SiteName +'</td>        <td> '+ value.SiteUrl +'</td>        <td>'+ value.SiteDesc +'</td>        <td>'+ value.SiteType +'</td>        <td style="width: 30%; text-align: right;">         <a href="'+ value.SiteUrl +'" target="_Blank" class="btn btn-sm btn-info"> Browse </a></td>    </tr>');
              });
             $('#webdirtable').append('</tbody>');
          },
        });


  });





});

</script>

@endsection


<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Link Reference</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

         <form action="{{route('linkpost')}}" method="post" enctype="multipart/form-data">
               @csrf

                <div class="form-group">
                  <label for="exampleInputEmail1">Super Category</label>
                  <table>
                    <tr>
                      <td><input type="text" class="form-control" name="" value=""></td>
                      <td><input type="text" class="form-control" name="" value=""></td>
                      <td><input type="text" class="form-control" name="" value=""></td>
                    </tr>
                    </table>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Site Title</label>
                  <input type="text" class="form-control" id="servicename" name="SiteName" aria-describedby="emailHelp" placeholder="Enter Service Name">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">URL</label>
                  <input type="text" class="form-control" id="servicoffer" name="SiteUrl" aria-describedby="emailHelp" placeholder="Applicable offer">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Site Description</label>
                  <textarea name="SiteDesc" class="form-control"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

      </div>
    </div>
  </div>
</div>







<!-- 



             $.each(data, function( key, value ) 
             {
              $('#webdirtable').append('<tr><td scope="row">'+ ++key +'</td>                    <td> '+ value.SiteName +'</td>        <td> '+ value.SiteUrl +'</td>        <td>'+ value.SiteDesc +'</td>        <td>'+ value.SiteType +'</td>        <td style="width: 30%; text-align: right;"><a href="'+ value.SiteUrl +'" target="_Blank" class="btn btn-sm btn-info"> Browse </a>          <a href="'+ value.id +'" class="btn btn-sm btn-danger"> Delete </a>        </td>    </tr>');
              });
             $('#webdirtable').append('</tbody>'); -->