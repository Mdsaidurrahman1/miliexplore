<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">

              <a href="<?php echo e(route('linklib')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Web Refference</a> 
              <a href="<?php echo e(route('object')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Object Library</a> 
               <a href="<?php echo e(route('settingsmodule')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Setup Module</a>  
               <a href="<?php echo e(route('settingsmodule')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Setup </a>  
               <a href="<?php echo e(route('module')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Working Module </a>  
              <a href="<?php echo e(route('report')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Show report</a> 
             
          </div>

          <div class="col-md-10">
            <p class="subtitle" > All Module</p> <hr>

                 <?php $__currentLoopData = $modulepack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="">
                      <div class="col-md-3 modhead">
                      <h4><?php echo e($mod->ModuleName); ?></h4>
                      <h5><?php echo e($mod->ModuleDesc); ?></h5>
                    </div>
                  </a>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>

    </div>

  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>