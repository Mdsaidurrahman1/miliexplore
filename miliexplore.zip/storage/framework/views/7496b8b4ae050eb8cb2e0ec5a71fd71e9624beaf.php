<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="login" class="login">
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-4 col-lg-offset-2 loginform" >

          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>




            <h2> Register here</h2>  
                  <?php if(Session::has('message')): ?>
                     <div class="alert alert-warning"><?php echo e(Session::get('message')); ?></div>
                  <?php endif; ?>
              <form action="<?php echo e(route('registerpost')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <input type="hidden" name="" value="">

                <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="username" aria-describedby="emailHelp" placeholder="Enter user name">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Email</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Password</label>
                  <input type="password" class="form-control" id="exampleInputEmail1" name="password" aria-describedby="emailHelp" placeholder="Enter email">
                </div>

               <br><input type="submit" class="btn btn-info"value="Register">
                <br>

              </form>


        </div>
        <div class="col-lg-4 col-lg-offset-2">
            
        </div>
        <div class="col-lg-4 col-lg-offset-2">

        </div>
      </div>

    </div>


  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>