<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-3 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-9 tail">
                <p><span style="font-size: 24px;color="red"> Work Management</span></p>
          </div>
        </div>
      </div>
<i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-3 menu">
              <a href="<?php echo e(route('admin_news')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Message</a> 
              <a href="<?php echo e(route('admin_service')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-home"> </i> Service</a> 
              <a href="<?php echo e(route('admin_work')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Work</a> 
              <a href="<?php echo e(route('admin_content')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Content Management</a>
             
          </div>

          <div class="col-md-9">

           <div class="contentsection">
                <?php if(Session::has('message')): ?>
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> <?php echo e(Session::get('message')); ?>    
                  </div>
                  <?php endif; ?>
              <button class="btn btn-success"  data-toggle="modal" data-target="#exampleModal">Create New Work</button> <hr>

              <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Work Name</th>
                    <th scope="col">Picture</th>
                    <th scope="col">Price</th>
                    <th scope="col">Client Name</th>
                    <th scope="col">Contact</th>
                    <th scope="col" style="width: 30%; text-align: right;">Done job Manage</th>
                  </tr>
                </thead>
                <tbody>
                 <?php $i = 1 ?>
                 <?php $__currentLoopData = $workpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($work->Work_name); ?></td>
                    <td> <img src="<?php echo e(URL::asset($work->Work_picture)); ?>" style="width: 200px;"></td>
                    <td><?php echo e($work->Price); ?></td>
                    <td><?php echo e($work->Client_name); ?></td>
                    <td><?php echo e($work->Client_contact); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="<?php echo e(url('/workdelete/'.$work->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>



<?php $__env->stopSection(); ?>


 <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert a Finish Job</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

<!--             'Work_name' => 'required',
            'Work_desc' => 'required',
            'Price' => 'required',
            'Client_name' => 'required',
            'Work_picture' => 'required',
            'Client_contact' => 'required' -->


      <div class="modal-body">
        <form action="<?php echo e(route('workpost')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="exampleInputEmail1">Job Name</label>
            <input type="text" class="form-control" id="jobname" name="Work_name" aria-describedby="emailHelp" value="name" placeholder="Enter Job Title">
          </div>

          <div class="form-group">
            <label for="exampleInputPassword1">Description</label>
            <textarea name="Work_desc" class="form-control"></textarea>
          </div>

          <div class="form-group">
            <label for="exampleInputEmail1">Price</label>
            <input type="text" class="form-control" value="123" id="Price" name="Price" aria-describedby="emailHelp" placeholder="Job price">
          </div>

          <div class="form-group">
            <label for="exampleInputEmail1">Client</label>
            <input type="text" class="form-control" value="client" id="jobclient" name="Client_name" aria-describedby="emailHelp" placeholder="Client information">
          </div>

          <div class="form-group">
            <label for="exampleInputEmail1">Client contact</label>
            <input type="text" class="form-control" value="clientcontact" id="clientcontact" name="Client_contact" aria-describedby="emailHelp" placeholder="Client information">
          </div>

          <div class="form-group">
            <label for="exampleInputEmail1">Select picture</label>
            <input type="file" id="servicpicutre" name="Work_picturex" aria-describedby="emailHelp" >
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>

    </div>
  </div>
</div>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>