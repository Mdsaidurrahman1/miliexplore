<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="login" class="login">
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-4 col-lg-offset-2 loginform" >


              <?php if(Session::has('Successmessage')): ?>
                  <div class="alert alert-info">
                      User Created successfully! Please login
                </div>
             <?php endif; ?>
              
            <?php if(Session::has('message')): ?>
               <div class="alert alert-danger"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>

              <br>
              <h2> Login here</h2>  
              <form action="<?php echo e(route('loginpost')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <input type="hidden" name="" value="">

                <label class=""> User name</label><br>
                <input type="text" name="username" class="form-control" value="saidur" placeholder="Enter name">

                <br><label class=""> User Password</label><br>
                <input type="password" name="userpassword" class="form-control" value="asdf" placeholder="Enter password">

               <br><input type="submit" class="btn btn-info"value="Login">
                <br>

              </form>


        </div>
        <div class="col-lg-4 col-lg-offset-2">
            
        </div>
        <div class="col-lg-4 col-lg-offset-2">

        </div>
      </div>

    </div>


  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>