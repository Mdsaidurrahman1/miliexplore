<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red">Object Library </span></p>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">
          <div class="col-md-2 menu">
              <a href="<?php echo e(url('/admin')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Admin Operation</a>            
          </div>

          <div class="col-md-2 sideform">
            <p class="subtitle" > Enter new Object</p>
            <form action="<?php echo e(route('objectentitypost')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>

                 <div class="form-group">
                  <label for="exampleInputEmail1">Super Category</label>
                  <select class="form-control" id="supercategory" name="supercategory">
                    <option class="Education">Select Category</option>
                      <?php $__currentLoopData = $catpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->SuperCateName); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Category</label>
                  <select class="form-control" id="category" name="scategory">
                    <option class="Education">Select Category</option>
                  </select>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Sub Category</label>
                  <select class="form-control" id="subcategory" name="subcategory">
                    <option class="Education">Select Category</option>
                  </select>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Object Category</label>
                  <select class="form-control" id="objcategory" name="objcategory">
                    <option class="Education">Select Category</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Object Name</label>
                  <input type="text" class="form-control" id="objectname" name="ObjectName" aria-describedby="emailHelp" placeholder="Enter Service Name">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Site Description</label>
                  <textarea name="ObjectDetail" class="form-control"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

          </div>

          <div class="col-md-8">

           <div class="contentsection">
            <div class="row searchment">
              <div class="col-md-2">
                   <div class="form-group">
                    <label for="exampleInputEmail1">Super Category</label>
                    <select class="form-control" id="searchsupercat" name="supercategory">
                      <option class="Education">Select Category</option>
                        <?php $__currentLoopData = $catpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->SuperCateName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
              </div>
              <div class="col-md-2">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Category</label>
                    <select class="form-control" id="searchCat" name="scategory" >
                      <option class="Education" >Choose Previous</option>
                    </select>
                  </div>
              </div>
              <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">Sub Category</label>
                  <select class="form-control" id="Searchsubcategory" name="subcategory">
                    <option class="Education">Choose Previous</option>
                  </select>
                </div>
              </div>
              <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">Object Category</label>
                  <select class="form-control" id="Searchobjcat" name="objcategory">
                    <option class="Education">Choose Previous</option>
                  </select>
                </div>
              </div>

              <div class="col-md-2" id="newobject">
                <div class="form-group">
                  <label for="exampleInputEmail1"> Object Entry</label>
                    <button type="button"  class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                      Insert Object
                    </button>

                </div>
              </div>
              
            </div>





  

             <p class="subtitle" > All Registerd Object_______________________________________</p>

              <table class="table table-sm table-hover" id="resultobjtable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Object Name</th>
                    <th scope="col">Type Info</th>
                    <th scope="col">Description</th>
                    <th scope="col">Category ID </th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage Service</th>
                  </tr>
                </thead>  
                <tbody>
                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $objpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($oj->ObjectName); ?></td>
                    <td> <?php echo e($oj->ObjectType); ?></td>
                    <td> <?php echo e($oj->ObjectDetail); ?></td>
                    <td><?php echo e($oj->ObjectCateId); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="<?php echo e(url('/objectdetail/'.$oj->id)); ?>" class="btn btn-sm btn-info"> Explore </a>
                      <a href="<?php echo e(url('/objdelete/'.$oj->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>


<script type="text/javascript">



  $( "#newobject" ).hide();


$(document).ready(function(){


  

  $( "#searchsupercat" ).change(function() {
    var supCateKey = $("#searchsupercat").val();
     $.ajax({
          url:"<?php echo e(url('/searchBySupCate')); ?>",
          method: 'GET',
          data: {'key':supCateKey},
            
          success: function(data)
          {
            $('#resultobjtable').html('');
            //
            $('#resultobjtable').append('<thead><tr><th scope="col">#</th><th scope="col">Object Name</th><th scope="col">Object Type</th><th scope="col">Object Detail</th><th scope="col" style="width: 30%; text-align: right;">Manage Service</th></tr></thead><tbody>');

             $.each(data, function( key, value ) 
             {
              $('#resultobjtable').append('<tr><td scope="row">'+ ++key +'</td><td> '+ value.ObjectName +'</td>        <td> '+ value.ObjectType +'</td><td>'+ value.ObjectDetail +'</td>       <td style="width: 30%; text-align: right;"> <a href="<?php echo e(url('/objectdetail')); ?>/'+value.id+'"  class="btn btn-sm btn-info"> Explore </a>          <a href="'+value.id+'" class="btn btn-sm btn-danger"> Delete </a>        </td>    </tr>');
                });
             $('#resultobjtable').append('</tbody>');

          }});

          //var supCateKey = $("#searchsupercat").val();
          $.ajax({
          url:"<?php echo e(url('/getcategory')); ?>",
          method: 'GET',
          data: {'key':supCateKey},

          success: function(result)
          {
             $('#searchCat').html('');
             $('#searchCat').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#searchCat').append('<option value="'+value.id+'">'+ value.CategoryName +'</option>');
             });
          }});

  });




  $( "#searchCat" ).change(function() {
    var supCateKey = $("#searchsupercat").val();
    var CateKey = $("#searchCat").val();
     $.ajax({
          url:"<?php echo e(url('/searchByCate')); ?>",
          method: 'GET',
          data: {'SupCatekey':supCateKey,'Catekey':CateKey},
            
          success: function(data)
          {
            $('#resultobjtable').html('');
            //
            $('#resultobjtable').append('<thead><tr><th scope="col">#</th><th scope="col">Object Name</th><th scope="col">Object Type</th><th scope="col">Object Detail</th><th scope="col" style="width: 30%; text-align: right;">Manage Service</th></tr></thead><tbody>');

             $.each(data, function( key, value ) 
             {
              $('#resultobjtable').append('<tr><td scope="row">'+ ++key +'</td><td> '+ value.ObjectName +'</td>        <td> '+ value.ObjectType +'</td><td>'+ value.ObjectDetail +'</td>       <td style="width: 30%; text-align: right;"> <a href="<?php echo e(url('/objectdetail/')); ?>"  class="btn btn-sm btn-info"> Explore </a>          <a href="'+ value.id +'" class="btn btn-sm btn-danger"> Delete </a>        </td>    </tr>');
                });
             $('#resultobjtable').append('</tbody>');


          }});


          $.ajax({
          url:"<?php echo e(url('/getsubcategory')); ?>",
          method: 'GET',
          data: {'key':CateKey},

          success: function(result)
          {
             $('#Searchsubcategory').html('');
             $('#Searchsubcategory').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#Searchsubcategory').append('<option value="'+value.id+'">'+ value.SubCatName +'</option>');
             });
          }});

  });







 $( "#Searchsubcategory" ).change(function() {
    var supCateKey = $("#searchsupercat").val();
    var CateKey = $("#searchCat").val();
    var SubCateKey = $("#Searchsubcategory").val();
     $.ajax({
          url:"<?php echo e(url('/searchBySubCate')); ?>",
          method: 'GET',
          data: {'SupCatekey':supCateKey,'Catekey':CateKey,'SubCatkey':SubCateKey},
            
          success: function(data)
          {
            $('#resultobjtable').html('');
            //
            $('#resultobjtable').append('<thead><tr><th scope="col">#</th><th scope="col">Object Name</th><th scope="col">Object Type</th><th scope="col">Object Detail</th><th scope="col" style="width: 30%; text-align: right;">Manage Service</th></tr></thead><tbody>');

             $.each(data, function( key, value ) 
             {
              $('#resultobjtable').append('<tr><td scope="row">'+ ++key +'</td><td> '+ value.ObjectName +'</td>        <td> '+ value.ObjectType +'</td><td>'+ value.ObjectDetail +'</td>       <td style="width: 30%; text-align: right;"> <a href="<?php echo e(url('/objectdetail/')); ?>"  class="btn btn-sm btn-info"> Explore </a>          <a href="'+ value.id +'" class="btn btn-sm btn-danger"> Delete </a>        </td>    </tr>');
                });
             $('#resultobjtable').append('</tbody>');


          }});


          $.ajax({
          url:"<?php echo e(url('/getobjcat')); ?>",
          method: 'GET',
          data: {'key':SubCateKey},

          success: function(result)
          {
             $('#Searchobjcat').html('');
             $('#Searchobjcat').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#Searchobjcat').append('<option value="'+value.id+'">'+ value.ObjectCatName +'</option>');
             });
          }});

  });





 $( "#Searchobjcat" ).change(function() {
    var supCateKey = $("#searchsupercat").val();
    var CateKey = $("#searchCat").val();
    var SubCateKey = $("#Searchsubcategory").val();
    var objCateKey = $("#Searchobjcat").val();
     $( "#newobject" ).show();
     $.ajax({
          url:"<?php echo e(url('/searchByObjCate')); ?>",
          method: 'GET',
          data: {'SupCatekey':supCateKey,'Catekey':CateKey,'SubCatkey':SubCateKey,'ObjCatId':objCateKey},
            
          success: function(data)
          {
            $('#resultobjtable').html('');
            //
            $('#resultobjtable').append('<thead><tr><th scope="col">#</th><th scope="col">Object Name</th><th scope="col">Object Type</th><th scope="col">Object Detail</th><th scope="col" style="width: 30%; text-align: right;">Manage Service</th></tr></thead><tbody>');

             $.each(data, function( key, value ) 
             {
              $('#resultobjtable').append('<tr><td scope="row">'+ ++key +'</td><td> '+ value.ObjectName +'</td>        <td> '+ value.ObjectType +'</td><td>'+ value.ObjectDetail +'</td>       <td style="width: 30%; text-align: right;">     <a href="<?php echo e(url('/objectdetail/')); ?>"  class="btn btn-sm btn-info"> Explore </a>          <a href="'+ value.id +'" class="btn btn-sm btn-danger"> Delete </a>        </td>    </tr>');
                });
             $('#resultobjtable').append('</tbody>');


          }});


  });







  $( "#supercategory" ).change(function() {
    var superecatkey = $("#supercategory").val();
     $.ajax({
          url:"<?php echo e(url('/getcategory')); ?>",
          method: 'GET',
          data: {'key':superecatkey},

          success: function(result)
          {
             $('#category').html('');
             $('#category').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#category').append('<option value="'+value.id+'">'+ value.CategoryName +'</option>');
             });
          }});
  });




  $( "#category" ).change(function() {
    var catkey = $("#category").val();
     $.ajax({
          url:"<?php echo e(url('/getsubcategory')); ?>",
          method: 'GET',
          data: {'key':catkey},

          success: function(result)
          {
             $('#subcategory').html('');
             $('#subcategory').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#subcategory').append('<option value="'+value.id+'">'+ value.SubCatName +'</option>');
             });
          }});
  });







  $( "#subcategory" ).change(function() {
    var subcateid = $("#subcategory").val();
     $.ajax({
          url:"<?php echo e(url('/getobjcat')); ?>",
          method: 'GET',
          data: {'key':subcateid},

          success: function(result)
          {
             $('#objcategory').html('');
             $('#objcategory').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#objcategory').append('<option value="'+value.id+'">'+ value.ObjectCatName +'</option>');
             });
          }});
  });


});
</script>
















<?php $__env->stopSection(); ?>


   
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Object </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

         <form action="<?php echo e(route('linkpost')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label for="exampleInputEmail1">Super Category</label>
                  <table>
                    <tr>
                      <td><input type="text" class="form-control" name="" value=""></td>
                      <td><input type="text" class="form-control" name="" value=""></td>
                      <td><input type="text" class="form-control" name="" value=""></td>
                      <td><input type="text" class="form-control" name="" value=""></td>
                    </tr>
                    </table>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Object Name</label>
                  <input type="text" class="form-control" id="servicename" name="SiteName" aria-describedby="emailHelp" placeholder="Enter Name">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Object Description</label>
                  <textarea name="SiteDesc" class="form-control"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

      </div>
    </div>
  </div>
</div>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>