<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
<!--       <div class="row">
        <div class="">
          <div class="col-md-3 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-9 tail">
                <p>Admin Dashboard</p>
          </div>
        </div>
      </div> -->
    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
              <a href="<?php echo e(route('admin_service')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Service</a> 
              <a href="<?php echo e(route('admin_work')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Product</a> 
              <a href="<?php echo e(route('admin_content')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Site Content </a>
              <a href="<?php echo e(route('linklib')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Web Refference</a> 
              <a href="<?php echo e(route('admin_news')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Company Register</a>
              <a href="<?php echo e(route('admin_news')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> User Management</a> 
              <a href="<?php echo e(route('admin_news')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Client Management</a>  
               <a href="<?php echo e(route('settingsmodule')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Setup Module</a>  
             
          </div>

          <div class="col-md-10">
          </div>

    </div>

  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>