      


<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      


      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red"> Super Category Setup Info Management</span></p>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
              <a href="<?php echo e(route('settingsmodule')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Setup Module</a>  
          </div>

          <div class="col-md-3 sideform">
            <p class="subtitle" > New Super Category</p>
            <form action="<?php echo e(route('supercatpost')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="exampleInputPassword1">Super Category Name </label>
                  <input type="text" class="form-control" id="servicoffer" name="SuperCateName" aria-describedby="emailHelp" placeholder="Super Category Name">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Super Category Description</label>
                  <textarea name="SuperCateDesc" class="form-control"></textarea>
                </div>

               <div class="form-group">
                  <label for="exampleInputEmail1">Super Category Type</label>
                  <select class="form-control" id="servicoffer" name="SuperCateType" >
                    <option value=""> Select Type</option>
                    <option value="Physical"> Physical</option>
                    <option value="Logical"> Logical</option>
                    <option value="Virtual"> Virtual</option>
                  </select>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

          </div>

          <div class="col-md-7">

           <div class="contentsection">
    
                  <?php if(Session::has('message')): ?>
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> <?php echo e(Session::get('message')); ?>    
                  </div>
                  <?php endif; ?>

             <p class="subtitle" > All Super Category info</p>

              <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Category Name</th>
                    <th scope="col">Category Description</th>
                    <th scope="col">Category Type</th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage Service</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $supercatpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($cat->SuperCateName); ?></td>
                    <td> <?php echo e($cat->SuperCateDesc); ?></td>
                    <td><?php echo e($cat->SuperCateType); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="<?php echo e(url('/supercatdelete/'.$cat->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>