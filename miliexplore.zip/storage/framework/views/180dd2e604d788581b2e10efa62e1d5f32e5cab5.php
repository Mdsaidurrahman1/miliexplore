<?php $__env->startSection('content'); ?>

    <!-- Carousel -->
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
      </ol>
      <!-- Wrapper for slides -->
      <div class="carousel-inner">
        <div class="item active">
          <img src="<?php echo e(URL::asset('resources/assets/img/slide1.jpg')); ?>" alt="First slide">

        </div>
        <div class="item">
          <img src="<?php echo e(URL::asset('resources/assets/img/slide2.jpg')); ?>" alt="Second slide">
          <!-- Static Header -->
<!--           <div class="header-text hidden-xs">
            <div class="col-md-12 text-center">
              <h2><span>Clean all kinds of furniture</span></h2>
              <br>
              <h3><span>Floor cleaning, dry cleaning, washing of you furniture</span></h3>
              <br>
              <div class="">
                <a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('service')); ?>">Our Service</a><a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('product')); ?>">Our works</a>
              </div>
            </div>
          </div> -->
          <!-- /header-text -->
        </div>
        <div class="item">
          <img src="<?php echo e(URL::asset('resources/assets/img/slide3.jpg')); ?>" alt="Third slide">
          <!-- Static Header -->
 <!--          <div class="header-text hidden-xs">
            <div class="col-md-12 text-center">
              <h2><span>Maintainance your home and office equipment</span></h2>
              <br>
              <h3><span>Repairing, polish, color, swing, sales etc.</span></h3>
              <br>
              <div class="">
                <a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('service')); ?>">Our Service</a><a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('product')); ?>">Our works</a>
              </div>
            </div>
          </div> -->
          <!-- /header-text -->
        </div>
      </div>
      <!-- Controls -->
      <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
		    <span class="glyphicon glyphicon-chevron-left"></span>
			</a>
      <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
		    <span class="glyphicon glyphicon-chevron-right"></span>
			</a>
    </div>
    <!-- /carousel -->
  </section>
  <!-- /Section: intro -->
<section>
    <div class="techholder">
    <img src="<?php echo e(URL::asset('resources/assets/img/techcom.png')); ?>" alt="" style="width:100%">
    </div>
</section>





  <section>
    <div class=" homecontent" style="background-image:url(<?php echo e(URL::asset('resources/assets/img/back6.png')); ?>)">
      <div class="row ">

        <div class="col-md-9 videoarea">
               <h2>Welcome to <span><img src="<?php echo e(URL::asset('resources/assets/img/logo.png')); ?>" alt="" style="width:300px;"></span></h2>
                <p style="text-align: justify;" class="infotext">
                  miliscript is trying to be established his as an IT enable institution in Bangladesh with all modern technologies and tools. Its working to build this mordern world through ICT. Implementing IT support at every level of your life like living, education, support, shairing, exchanging, business, security and entertainment also.
                  <br><br>
                  Micro Intelligence for Life-relevent Insvestigaion Script (miliscript.com) is studing to find the best way to use ICT in our daily life activities. How we can use ICT in our life for incresing our productivity, knowledge, life status, social relationship, business, serving humanity and ensure social security are our main concern and its also our mission.
                  <br><br>
                  miliscript team does those works by analysing huge amount of relevent data by some self developed algorithm, tools and different machanism and the team is well educated and technology based.
                </p>
        </div>

        <div class="col-md-3 newsarea">
            <h4>News and Notice</h4>
            
              <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(URL::asset($msg->Message_picture)); ?>" class="alert-link">
                <div class="alert alert-info" role="alert">
                <span class="glyphicon glyphicon-align-justify" aria-hidden="true"> </span> <?php echo e($msg->Message_subject); ?>

                </div>
              </a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


          
        </div>

      </div>
    </div>
  </section>


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>