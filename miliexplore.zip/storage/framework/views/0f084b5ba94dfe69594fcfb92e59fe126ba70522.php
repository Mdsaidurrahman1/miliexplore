<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>

          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red">Object Library Management</span></p>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">
          <div class="col-md-2 menu">
              <a href="<?php echo e(url('/object')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Object library</a>
              <p> New Object Entry</p>
              <form action="" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <input type="hidden" name="objectid" value="<?php echo e($object->id); ?>">
               

                <div class="form-group">
                  <label for="exampleInputEmail1">Object Entity Name</label>
                  <input type="text" class="form-control" id="objectname" name="ddddd" aria-describedby="emailHelp" placeholder="Enter Object Name">
                </div>

                <button type="submit" class="btn btn-primary">Save</button>
              </form>         <hr>

              <p> New Property Setup</p>
              <form action="<?php echo e(route('propertyin')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <input type="hidden" name="objectid" value="<?php echo e($object->id); ?>">
               

                <div class="form-group">
                  <label for="exampleInputEmail1">Property Name</label>
                  <input type="text" class="form-control" id="objectname" name="PropertyName" aria-describedby="emailHelp" placeholder="Enter Property Name">
                </div>

                <button type="submit" class="btn btn-primary">Save</button>
              </form>       
          </div>

          <div class="col-md-2 sideform">

            <p class="subtitle" > Setup</p>
            <form action="<?php echo e(route('objectentitypost')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label for="exampleInputEmail1">Select Properties</label>
                  <select class="form-control" id="category" name="scategory">
                    <option class="Education">Select Property</option>
                    <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($ppt->id); ?>"><?php echo e($ppt->PropertyName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Object Name</label>
                  <input type="text" class="form-control" id="objectname" name="ObjectName" aria-describedby="emailHelp" placeholder="Enter Value">
                </div>

                <button type="submit" class="btn btn-primary">Save</button>
              </form>
              <hr>

            <form action="<?php echo e(route('objectentitypost')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label for="exampleInputEmail1">Action Name</label>
                  <input type="text" class="form-control" id="objectname" name="ObjectName" aria-describedby="emailHelp" placeholder="Enter Action">
                </div>

                <button type="submit" class="btn btn-primary">Save</button>
              </form>
          </div>

          <div class="col-md-8">

           <div class="contentsection">


             <p class="subtitle" > Object Entity: <span style="font-weight: bold;"><u><?php echo e($object->ObjectName); ?></u></span> <br>

             Object Type : <span style="font-weight: bold;"><u><?php echo e($object->ObjectType); ?></u></span> </p>

             <hr>
              </div>


          </div>

    </div>

  </section>


<script type="text/javascript">

$(document).ready(function(){



  $( "#supercategory" ).change(function() {
    var superecatkey = $("#supercategory").val();
     $.ajax({
          url:"<?php echo e(url('/getcategory')); ?>",
          method: 'GET',
          data: {'key':superecatkey},

          success: function(result)
          {
             $('#category').html('');
             $('#category').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#category').append('<option value="'+value.id+'">'+ value.CategoryName +'</option>');
             });
          }});
  });




  $( "#category" ).change(function() {
    var catkey = $("#category").val();
     $.ajax({
          url:"<?php echo e(url('/getsubcategory')); ?>",
          method: 'GET',
          data: {'key':catkey},

          success: function(result)
          {
             $('#subcategory').html('');
             $('#subcategory').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#subcategory').append('<option value="'+value.id+'">'+ value.SubCatName +'</option>');
             });
          }});
  });







  $( "#subcategory" ).change(function() {
    var subcateid = $("#subcategory").val();
     $.ajax({
          url:"<?php echo e(url('/getobjcat')); ?>",
          method: 'GET',
          data: {'key':subcateid},

          success: function(result)
          {
             $('#objcategory').html('');
             $('#objcategory').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#objcategory').append('<option value="'+value.id+'">'+ value.ObjectCatName +'</option>');
             });
          }});
  });


});
</script>
















<?php $__env->stopSection(); ?>


   
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert New Service in Business</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
    </div>
  </div>
</div>




<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>