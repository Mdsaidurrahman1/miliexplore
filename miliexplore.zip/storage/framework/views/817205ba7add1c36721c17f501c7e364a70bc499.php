<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>

	<a href="<?php echo e(route('reportshow')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Show report</a> 
  	<h1> Report </h1>

</body>
</html>