<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red">Link Library Management</span></p>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
              <a href="<?php echo e(url('/admin')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Admin Operation</a>
              <a href="<?php echo e(route('webdirectory')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Web Directory</a>               
          </div>

          <div class="col-md-3 sideform">
            <p class="subtitle" > Enter new site info</p>
            <form action="<?php echo e(route('linkpost')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label for="exampleInputEmail1">Super Category</label>
                  <select class="form-control" id="supercategory" name="supercategory">
                    <option class="Education">Select Category</option>
                      <?php $__currentLoopData = $catpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->SuperCateName); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Category</label>
                  <select class="form-control" id="category" name="scategory">
                    <option class="Education">Select Category</option>
                  </select>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Sub Category</label>
                  <select class="form-control" id="subcategory" name="subcategory">
                    <option class="Education">Select Category</option>
                  </select>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Site Title</label>
                  <input type="text" class="form-control" id="servicename" name="SiteName" aria-describedby="emailHelp" placeholder="Enter Service Name">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">URL</label>
                  <input type="text" class="form-control" id="servicoffer" name="SiteUrl" aria-describedby="emailHelp" placeholder="Applicable offer">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Site Description</label>
                  <textarea name="SiteDesc" class="form-control"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

          </div>

          <div class="col-md-7">

           <div class="contentsection">
    
                  <?php if(Session::has('message')): ?>
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> <?php echo e(Session::get('message')); ?>    
                  </div>
                  <?php endif; ?>

             <p class="subtitle" > All site info</p>

              <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Site Name</th>
                    <th scope="col">Site Link</th>
                    <th scope="col">Description</th>
                    <th scope="col">Type </th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage Service</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $linkpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($link->SiteName); ?></td>
                    <td> <?php echo e($link->SiteUrl); ?></td>
                    <td><?php echo e($link->SiteDesc); ?></td>
                    <td><?php echo e($link->SiteType); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="<?php echo e(($link->SiteUrl)); ?>" target="_Blank" class="btn btn-sm btn-info"> Browse </a>
                      <a href="<?php echo e(url('/linkdelete/'.$link->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>


<script type="text/javascript">

$(document).ready(function(){












  $( "#supercategory" ).change(function() {
    var superecatkey = $("#supercategory").val();
     $.ajax({
          url:"<?php echo e(url('/getcategory')); ?>",
          method: 'GET',
          data: {'key':superecatkey},

          success: function(result)
          {
             $('#category').html('');
             $('#category').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#category').append('<option value="'+value.id+'">'+ value.CategoryName +'</option>');
             });
          }});
  });


  $( "#category" ).change(function() {
    var catkey = $("#category").val();
     $.ajax({
          url:"<?php echo e(url('/getsubcategory')); ?>",
          method: 'GET',
          data: {'key':catkey},

          success: function(result)
          {
             $('#subcategory').html('');
             $('#subcategory').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#subcategory').append('<option value="'+value.id+'">'+ value.SubCatName +'</option>');
             });
          }});
  });

});
</script>
















<?php $__env->stopSection(); ?>


   
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert New Service in Business</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
    </div>
  </div>
</div>




<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>