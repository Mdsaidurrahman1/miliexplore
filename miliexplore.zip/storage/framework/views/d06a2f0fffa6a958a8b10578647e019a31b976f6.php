<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="service" style="background-image:url(<?php echo e(URL::asset('resources/assets/img/bg.png')); ?>)" class="service" >
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-8 col-lg-offset-2">
          <div class="wow flipInY" data-wow-offset="0" data-wow-delay="0.4s">
            <div class="section-heading text-center">
              <h2 class="h-bold">Our Service for you</h2>

            </div>
          </div>
        </div>
      </div>

    </div>

    <div class="text-center">
      <div class="container">

        <div class="row">

        <?php $__currentLoopData = $servicepack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-3">
            <div class="wow fadeInLeft" data-wow-delay="0.2s">
              <div class="service-box">
                <div class="service-icon">
                  <img src="<?php echo e(URL::asset($service->service_picture)); ?>" class="img-responsive" alt="img">
                </div>
                <div class="service-desc">
                  <h5> <?php echo e($service->Service_name); ?></h5>
                  <p><?php echo e($service->Service_desc); ?></p>
                  <!-- <a href="#" class="btn btn-skin">See more</a> -->
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
      </div>
    </div>
  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>