<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-3 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-9 tail">
                <p><span style="font-size: 24px;color="red"> Service Management</span></p>
          </div>
        </div>
      </div>
<i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-3 menu">
              <a href="<?php echo e(route('admin_news')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Message</a> 
              <a href="<?php echo e(route('admin_service')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-home"> </i> Service</a> 
              <a href="<?php echo e(route('admin_work')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Work</a> 
              <a href="<?php echo e(route('admin_content')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Content Management</a>
             
          </div>

          <div class="col-md-9">

           <div class="contentsection">
              

                  <?php if(Session::has('message')): ?>
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> <?php echo e(Session::get('message')); ?>    
                  </div>
                  <?php endif; ?>



              <button class="btn btn-success"  data-toggle="modal" data-target="#exampleModal">Create new Service</button> <hr>



              <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Service</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Description</th>
                    <th scope="col">Price</th>
                    <th scope="col">Offer</th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage Service</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $servicepack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($service->Service_name); ?></td>
                    <td> <img src="<?php echo e(URL::asset($service->service_picture)); ?>" style="width: 200px;"></td>
                    <td><?php echo e($service->Service_desc); ?></td>
                    <td><?php echo e($service->Price); ?></td>
                    <td><?php echo e($service->Type); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="<?php echo e(url('/servicedelete/'.$service->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>



<?php $__env->stopSection(); ?>


   
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert New Service in Business</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('servicepost')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="exampleInputEmail1">Service Name</label>
            <input type="text" class="form-control" id="servicename" name="servicename" aria-describedby="emailHelp" placeholder="Enter Service Name">
          </div>

          <div class="form-group">
            <label for="exampleInputPassword1">Description</label>
            <textarea name="servicedesc" class="form-control"></textarea>
          </div>

          <div class="form-group">
            <label for="exampleInputEmail1">Price</label>
            <input type="number" class="form-control" id="serviceprice" name="serviceprice" aria-describedby="emailHelp" placeholder="Enter Service price">
          </div>

          <div class="form-group">
            <label for="exampleInputEmail1">Offer</label>
            <input type="text" class="form-control" id="servicoffer" name="servicoffer" aria-describedby="emailHelp" placeholder="Applicable offer">
          </div>

          <div class="form-group">
            <label for="exampleInputEmail1">Select picture</label>
            <input type="file" id="servicpicutre" name="servicpicture" aria-describedby="emailHelp" placeholder="Applicable offer">
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  </div>
</div>




<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>