      


<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      


      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red"> Working Module Register</span></p>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
              <a href="<?php echo e(url('/admin')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Admin</a>  
          </div>

          <div class="col-md-3 sideform">
            <p class="subtitle" > New Module</p>
            <form action="<?php echo e(route('addmodule')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>



                <div class="form-group">
                  <label for="exampleInputPassword1">Module Name </label>
                  <input type="text" class="form-control" id="servicoffer" name="ModuleName" aria-describedby="emailHelp" placeholder="Applicable offer">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Module Description</label>
                  <textarea name="ModuleDesc" class="form-control"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

          </div>

          <div class="col-md-7">

           <div class="contentsection">


             <p style="padding: 15px 2px; font-size: 32px; font-weight: bold;"> All Module info</p>

               <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">ModuleName</th>
                    <th scope="col">ModuleDesc</th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage Service</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $modulepack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($mod->ModuleName); ?></td>
                    <td> <?php echo e($mod->ModuleDesc); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="<?php echo e(($mod->SiteUrl)); ?>" target="_Blank" class="btn btn-sm btn-info"> Elements </a>
                      <a href="<?php echo e(url('/linkdelete/'.$mod->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>