<?php $__env->startSection('content'); ?>

    <!-- Carousel -->
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
      </ol>
      <!-- Wrapper for slides -->
      <div class="carousel-inner">
        <div class="item active">
          <img src="<?php echo e(URL::asset('resources/assets/img/slide1.jpg')); ?>" alt="First slide">
          <!-- Static Header -->
          <div class="header-text hidden-xs">
            <div class="col-md-12 text-center">
              <h2><span>Welcome to Washing Plant | Hamim Enterprise</span></h2>
              <br>
              <h3><span>We provide all kinds of support for you home & Office furniture</span></h3>
              <br>
              <div class="">
                <a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('service')); ?>">Our Service</a><a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('work')); ?>">Our works</a>
              </div>
            </div>
          </div>
          <!-- /header-text -->
        </div>
        <div class="item">
          <img src="<?php echo e(URL::asset('resources/assets/img/slide2.jpg')); ?>" alt="Second slide">
          <!-- Static Header -->
          <div class="header-text hidden-xs">
            <div class="col-md-12 text-center">
              <h2><span>Clean all kinds of furniture</span></h2>
              <br>
              <h3><span>Floor cleaning, dry cleaning, washing of you furniture</span></h3>
              <br>
              <div class="">
                <a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('service')); ?>">Our Service</a><a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('work')); ?>">Our works</a>
              </div>
            </div>
          </div>
          <!-- /header-text -->
        </div>
        <div class="item">
          <img src="<?php echo e(URL::asset('resources/assets/img/slide3.jpg')); ?>" alt="Third slide">
          <!-- Static Header -->
          <div class="header-text hidden-xs">
            <div class="col-md-12 text-center">
              <h2><span>Maintainance your home and office equipment</span></h2>
              <br>
              <h3><span>Repairing, polish, color, swing, sales etc.</span></h3>
              <br>
              <div class="">
                <a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('service')); ?>">Our Service</a><a class="btn btn-theme btn-sm btn-min-block" href="<?php echo e(route('work')); ?>">Our works</a>
              </div>
            </div>
          </div>
          <!-- /header-text -->
        </div>
      </div>
      <!-- Controls -->
      <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
		    <span class="glyphicon glyphicon-chevron-left"></span>
			</a>
      <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
		    <span class="glyphicon glyphicon-chevron-right"></span>
			</a>
    </div>
    <!-- /carousel -->

  </section>
  <!-- /Section: intro -->
  <section>
    <div class=" homecontent">
      <div class="row ">

        <div class="col-md-7 videoarea">
          <video width="100%" controls>
            <source src="<?php echo e(URL::asset('resources/assets/img/videoclip.mp4')); ?>" type="video/mp4">
            <source src="mov_bbb.ogg" type="video/ogg">
            Your browser does not support HTML5 video.
          </video>
        </div>

        <div class="col-md-3 newsarea">
            <h4>News and Notice</h4>
            
              <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(URL::asset($msg->Message_picture)); ?>" class="alert-link">
                <div class="alert alert-info" role="alert">
                <span class="glyphicon glyphicon-align-justify" aria-hidden="true"> </span> <?php echo e($msg->Message_subject); ?>

                </div>
              </a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            


                

            
        </div>

        <div class="col-md-2 addarea">
          Ads by google
        </div>
          
        </div>

      </div>
    </div>
  </section>


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>