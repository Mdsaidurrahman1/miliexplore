<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red"> Setup Info Management</span></p>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
              <a href="<?php echo e(url('/admin')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Admin Operation</a> 
              <a href="<?php echo e(route('Supercatsetup')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Super Categoty</a> 
              <a href="<?php echo e(route('Categorysetup')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Categoty</a>  
              <a href="<?php echo e(route('Subategorysetup')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Sub Categoty</a>  

             
          </div>

          <div class="col-md-3">
            <p style="padding: 15px 2px; font-size: 32px; font-weight: bold;"> Enter new site info</p>
            <form action="<?php echo e(route('linkpost')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="exampleInputEmail1">Site Title</label>
                  <input type="text" class="form-control" id="servicename" name="SiteName" aria-describedby="emailHelp" placeholder="Enter Service Name">
                </div>


                <div class="form-group">
                  <label for="exampleInputPassword1">Site Description</label>
                  <textarea name="SiteDesc" class="form-control"></textarea>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Site Category</label>
                  <select class="form-control" id="sitecategory" name="SiteCategory">
                    <option class="Education">Education</option>
                    <option class="Learning">Learning</option>
                    <option class="Business">Business</option>
                    <option class="Bank">Bank</option>
                    <option class="Company">Company</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Site Type</label>
                  <select class="form-control" id="sitetype" name="SiteType">
                    <option class="Education">Education</option>
                    <option class="Learning">Learning</option>
                    <option class="Business">Business</option>
                    <option class="Bank">Bank</option>
                    <option class="Company">Company</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">URL</label>
                  <input type="text" class="form-control" id="servicoffer" name="SiteUrl" aria-describedby="emailHelp" placeholder="Applicable offer">
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

          </div>

          <div class="col-md-7">

           <div class="contentsection">
    
                  <?php if(Session::has('message')): ?>
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> <?php echo e(Session::get('message')); ?>    
                  </div>
                  <?php endif; ?>

             <p style="padding: 15px 2px; font-size: 32px; font-weight: bold;"> All site info</p>

              <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Site Name</th>
                    <th scope="col">Site Link</th>
                    <th scope="col">Description</th>
                    <th scope="col">Category</th>
                    <th scope="col">Type </th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage Service</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $linkpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($link->SiteName); ?></td>
                    <td> <?php echo e($link->SiteUrl); ?></td>
                    <td><?php echo e($link->SiteDesc); ?></td>
                    <td><?php echo e($link->SiteCategory); ?></td>
                    <td><?php echo e($link->SiteType); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="http://<?php echo e(($link->SiteUrl)); ?>" target="_Blank" class="btn btn-sm btn-info"> Browse </a>
                      <a href="<?php echo e(url('/linkdelete/'.$link->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>



<?php $__env->stopSection(); ?>


   
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert New Service in Business</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
    </div>
  </div>
</div>




<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>